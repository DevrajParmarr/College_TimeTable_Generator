module.exports = [
  { id: "1", name: "Computer Science Engineering", code: "CSE" },
  { id: "2", name: "Information Technology", code: "IT" },
  { id: "3", name: "Electronics & Communication", code: "ECE" },
  { id: "4", name: "Mechanical Engineering", code: "ME" },
  { id: "5", name: "Civil Engineering", code: "CE" },
];
