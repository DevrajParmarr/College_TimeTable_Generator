module.exports = [
  { id: "1", name: "Room 101", capacity: 90, building: "Block A" },
  { id: "2", name: "Room 102", capacity: 60, building: "Block A" },
  { id: "3", name: "Room 103", capacity: 40, building: "Block A" },
  { id: "4", name: "Room 201", capacity: 90, building: "Block B" },
  { id: "5", name: "Room 202", capacity: 60, building: "Block B" },
  { id: "6", name: "Room 203", capacity: 40, building: "Block B" },
  { id: "7", name: "Room 301", capacity: 90, building: "Block C" },
  { id: "8", name: "Room 302", capacity: 60, building: "Block C" },
  { id: "9", name: "Room 303", capacity: 40, building: "Block C" },
  { id: "10", name: "Room 401", capacity: 60, building: "Block D" },
  { id: "11", name: "Room 402", capacity: 40, building: "Block D" },
];
